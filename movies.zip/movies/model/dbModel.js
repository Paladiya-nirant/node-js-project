const mongoose = require('mongoose');

const movieschema =new  mongoose.Schema({
    name : {
        type : String ,
        required : true
    },
    author : {
        type : String ,
        required : true
    },
    rate : {
        type : Number ,
        required : true
    },
    discript : {
        type : String ,
        required : true
    },
    language : {
        type : Array ,
        required : true
    },
    select : {
        type : String ,
        required : true
    },
    path : {
        type : String ,
        required : true
    } 
});

module.exports = mongoose.model('movie',movieschema);