const express = require('express');
let app = express()
const port = 3001;
const body_parser = require('body-parser')
const route = require('./route/route')
const mongoose = require('./db/db')
const d = require('./controllers/controller')
const path = require('path')

app.set('view engine' , 'ejs');

app.use(body_parser.urlencoded({extended : true}))

app.use('/views/uploads' , express.static('./views/uploads'));

app.use('/',route)

mongoose
app.listen(port , () =>{
    console.log("Port 3001 ");
})