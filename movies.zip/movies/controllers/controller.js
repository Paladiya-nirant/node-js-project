const { log } = require("console")
const flim = require("../model/dbModel")
const route = require("../route/route")
const multer = require("../upload/uploads")
const fs = require('fs')

let data = []

const defaultpath = async (req , res) =>{

    try{
        let movi =await flim.find()
        console.log(movi);
        res.render('index' , {movi});
    }
    catch(err){
        console.log(err);
    }

}

const addDoc = async (req , res) =>{
    console.log("this is our data" , req.body);    
    console.log(req.file.path);    

    try{
        const newTodo =await new flim({
            name : req.body.name ,
            author : req.body.author ,
            rate : req.body.rate ,
            discript : req.body.discript ,
            language : req.body.language ,
            select : req.body.select,
            path : req.file.path
        });
        console.log("its our movie list" , newTodo);
        newTodo.save();
        res.redirect('/detail');
    }
    catch(err){
        console.log("data not add" ,err);
        res.redirect('back')
    }
}
const detailDoc =async (req , res) =>{

    try{
        let movi =await flim.find()
        console.log(movi);
        res.render('detail' , {movi});
    }
    catch(err){
        console.log(err);
    }
}
const deleteDoc =async (req,res) =>{
  
    console.log("this is our delete log = " , req.params);
    
    try{
        const deleteData = await flim.findByIdAndDelete(req.params.id);
        fs.unlink(deleteData.path , () =>{
            console.log("img delete");
            res.redirect('/detail');
        })
    }
    catch(err){
        console.log("data has been not deleted",err);
    }
}

const editDoc = async (req , res) =>{
    console.log("editing",req.params);
    
    try{
        const editData = await flim.findById(req.params.id)
        console.log("edited");
        res.render('edit' , {editData})  
    }
    catch(err){
        console.log("Data has been not editing",err);
    } 

}

const updateDoc =async (req , res) =>{
    console.log("updating",req.body);

    const {id,name,author,rate,language,select,discript} = req.body
    const {path}=req.file
    try{
        const updatedata = await flim.findByIdAndUpdate(id,{name : name , author : author , rate : rate , language : language , select : select
            , discript : discript , path : path});
        fs.unlink(updatedata.path , () =>{
            console.log("img updated");
            res.redirect('/detail');
        })
        console.log("updated",updatedata);
        
    }
    catch(err){
        console.log("Data has been not updated");
    }
}

module.exports = {defaultpath , addDoc , deleteDoc , detailDoc , editDoc , updateDoc}