const express = require('express');
const route = express();
const d = require('../controllers/controller')
const filename = require('../upload/uploads')

route.get('/', d.defaultpath)                                           

route.post('/appDoc' , filename.single('file') , d.addDoc)

route.get('/detail' , d.detailDoc)

route.get('/deleteTodo/:id' , d.deleteDoc)

route.get('/editTodo/:id' , d.editDoc)

route.post('/updateDoc' , filename.single('file') , d.updateDoc)

module.exports = route ;